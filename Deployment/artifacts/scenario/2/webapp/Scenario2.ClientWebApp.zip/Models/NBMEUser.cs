﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Scenario2.TargetWebApp.Models
{
    public class NBMEUser
    {
        public string AuthToken { get; set; }
    }
}